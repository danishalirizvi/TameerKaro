USE [TameerKaroDB]
GO
-- 12345678
INSERT INTO [dbo].[Admin]
           ([Name]
           ,[Email]
           ,[Phone]
           ,[Username]
           ,[Password]
           ,[IsActive])
     VALUES
           ('Administrator'
           ,'admin@tameerkaro.com'
           ,'+9234568562'
           ,'admin'
           ,'1000:6SF0CnVufLI3O2l1qG5fcBMnx/n7i1cO:URL/PEvnF4w2RjTF0ryOWE82bDU='
           ,1)
GO


